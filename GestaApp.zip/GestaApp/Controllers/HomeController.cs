﻿using System.Diagnostics;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using GestaApp.Models;

namespace GestaApp.Controllers;

    // [Route("[controller]")]
    // [Route("[controller]/[action]")]
public class HomeController : Controller
{
   private readonly ILogger<HomeController> _logger;
     private readonly  carlogwapoContext _context;

    public HomeController(ILogger<HomeController> logger , carlogwapoContext context)
    {
        _logger = logger;
        _context = context;
    }
    public IActionResult Index()
   {
      {
      var lisofcategories =  _context.Categories.ToList();
        return View(lisofcategories);

    }


   }

    public IActionResult Privacy()
    {
      var lisofcategory =  _context.Categories.ToList();
        return View(lisofcategory);
    }

     public IActionResult Delete(int ID)
        {
            var carlogwapoDelete = _context.Categories.Where(q => q.Id == ID).FirstOrDefault();
            _context.Categories.Remove(carlogwapoDelete);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
