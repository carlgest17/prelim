using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using GestaApp.Models;

namespace GestaApp.Controllers;

public class CarloGwapoController : Controller
{
    public IActionResult Index(){
        return View();
    }
     public IActionResult siomai(){
        return View();
    }
        
}
