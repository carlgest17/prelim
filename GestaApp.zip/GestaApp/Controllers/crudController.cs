using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GestaApp.Models;
using Microsoft.Extensions.Logging;

namespace GestaApp.Controllers
{
    [Route("[controller]")]
    [Route("[controller]/[action]")]
    public class crudController : Controller
    {
         private readonly ILogger<crudController> _logger;
         private readonly carlogwapoContext _context;

        public crudController(carlogwapoContext context)
        {
            //   _logger = logger;
             _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
              return View(_context.Categories.ToList());
        }
        
        public IActionResult Create()
        {
            return View();
        }

         [HttpPost]
        public IActionResult Create(Category cat)
        {
            _context.Categories.Add(cat);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

          [HttpPost]
        public IActionResult Update(Category cate)
        {
            if(ModelState.IsValid)
            {
                _context.Categories.Update(cate);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }
            return View(cate);
        }

         public IActionResult Update(int ID)
        {
            var testuser = _context.Categories.Where(q => q.Id== ID).FirstOrDefault();
            return View(testuser);
        }

        public IActionResult Delete(int ID)
        {
            var categoryDelete = _context.Categories.Where(q => q.Id == ID).FirstOrDefault();
            _context.Categories.Remove(categoryDelete);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}