using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using GestaApp.Models;

namespace GestaApp.Controllers;

public class InfoController : Controller
{
    public IActionResult Index(){
         ViewData["age"] = 61;
        return View();

    }
     public IActionResult educ(){
        return View();
    }
      public IActionResult job(){
        return View();
    }
        
}
