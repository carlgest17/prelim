using Microsoft.EntityFrameworkCore;
using GestaApp.Models;

namespace GestaApp;

public class Startup
{


    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

public IConfiguration Configuration { get; }

public void ConfigureServices(IServiceCollection services)
   {

     services.AddDbContext<carlogwapoContext>(options => 
     options.UseMySql("server=localhost;database=carlogwapo;user=root", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.4.27-mariadb" )));
   
     services.AddControllersWithViews();
   }

   public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory){

}
   
    }

